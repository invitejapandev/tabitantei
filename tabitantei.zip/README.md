# Laravel-vue-3-starter

It's a pre-configured project using Laravel 8 and Vue 3

to get it up and run just clone it and enhoy coding :

     git clone https://github.com/boussadjra/laravel-vue-3-starter.git

     cd laravel-vue-3-starter



then install backend modules by running 

     composer install

and front-end modules :

     npm install

finally add your magic.     

