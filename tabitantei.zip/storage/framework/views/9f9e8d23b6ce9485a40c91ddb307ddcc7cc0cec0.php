<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Tabitantei 2</title>


    </head>
    <body>

        <div class="main_app" id="app">
            
            <router-view />
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>

    <style>
        @font-face {
            font-family: "CA-Geheimagent";
            src: url("fonts/CA-Geheimagent.woff") format('woff');
        }

        @font-face {
            font-family: "CA-Geheimagent";
            src: url("fonts/CA-Geheimagent-Bold.woff") format('woff');
            font-weight: bold;
        }

        @font-face {
            font-family: "CA-Geheimagent";
            src: url("fonts/CA-Geheimagent-Bold-Italic.woff") format('woff');
            font-weight: bold;
            font-style: italic;
        }

        @font-face {
            font-family: "CA-Geheimagent";
            src: url("fonts/CA-Geheimagent-Italic.woff") format('woff');
            font-style: italic;
        }


        body{
            margin:0;
            height: 100%;
            background: url(<?php echo e(URL::asset('images/green_bg.png')); ?>) no-repeat center center fixed;
            background-size: cover;
            font-family: CA-Geheimagent;
        }
        
       


    </style>
</html>
<?php /**PATH C:\Users\Ron\tabitantei\resources\views/welcome.blade.php ENDPATH**/ ?>