<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Tabitantei 2</title>


    </head>
    <body>

        <div  id="app">
            <router-link :to="{ name: 'main.index' }" class="text-sm font-medium">Login</router-link>
            <router-view />
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH D:\Downloads\laravel-vue-3-starter-main\test\resources\views/welcome.blade.php ENDPATH**/ ?>