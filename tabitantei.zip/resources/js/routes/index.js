import { createRouter, createWebHistory } from 'vue-router'

import MainIndex from '../components/Main'
import LoginIndex from '../components/Login'
import TeamSelect from '../components/TeamSelect'
import TextHolder from '../components/TextHolder'
import Mission from '../components/Mission'


const routes = [
    {
        path: '/main',
        name: 'main.index',
        component: MainIndex
    },
    {
        path: '/floor',
        name: 'main.index1',
        component: MainIndex,
        props: {
            miroCovered: false,
            elementImage: '/images/bulletin_board.png'
        }
    },
    {
        path: '/computer',
        name: 'main.index2',
        component: MainIndex,
        props: {
            miroCovered: true,
            elementImage: '/images/desk.png'
        }
    },
    {
        path: '/',
        name: 'login.index',
        component: LoginIndex
    },
    {
        path: '/team',
        name:'team.index',
        component: TeamSelect
    }
    ,
    {
        path: '/introduction',
        name:'introduction.index',
        component: TextHolder
    }
    ,
    {
        path: '/mission',
        name:'mission.index',
        component: Mission,
        props:{
            headerText:"testHeader",
            buttonText:"Enter the Game"
        }
    }
];

export default createRouter({
    history: createWebHistory(),
    routes
})