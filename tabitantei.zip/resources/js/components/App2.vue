<template>
<Main />
</template>

<script>

import Main from './Main.vue';

export default {


  name: 'App',
  components: {
    Main
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  height: 100vh;
}

html, body{
  margin: 0px !important;
}

</style>
