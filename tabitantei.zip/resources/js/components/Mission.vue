<template>
  <div class="textHolder">
        
         <span class="text_handler">{{ textShowned }}</span>
        <a class="btnReady" @click="gameStart">{{ buttonText }}</a>
    </div>
</template>

<script>
export default {
        name: 'Mission',
        data(){
            return {
                textShowned: `"Hello trainees. You will have to put your spy skills to work 
faster than we expected. We have an emergency. 
We have lost all contact with one of our agents, 
alias Mayumi, who was working on retrieving a famous 
painting for one of our clients.We have no idea where 
she went or why we lost contact with her, but her mission 
is vitally important. All our other agents are in the field, 
so it is up to you to meet this challenge. 
It appears that she was working somewhere in the 
Invite Japan Agency building before she left. Perhaps 
that is a good place to start…`
            }
        },
        methods:{
            gameStart(){
                this.$router.push({ name: 'main.index'+1 })
            }
        },
        props:{
            headerText: String,
            buttonText: String
        }
}
</script>

<style scoped>
    .textHolder{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }

    .text_handler{
        font-size: 3vw;
        padding: 4%;
        color: white;
        font-weight: regular;
        font-family: CA-Geheimagent;
        letter-spacing: 7px;
    }

    .btnReady{
        color:white;
        font-size: 3vw;
        border-style: solid;
        border-radius: 10px;
        padding: 10px;
        cursor: pointer;
        font-weight: regular;
        font-family: CA-Geheimagent;
    }


</style>