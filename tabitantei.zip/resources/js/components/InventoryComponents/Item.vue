<template>
    <h6>Item 1</h6>
</template>

<script>

export default{
    name: 'Item'
}


</script>