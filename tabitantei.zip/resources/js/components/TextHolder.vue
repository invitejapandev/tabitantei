<template>
  <div class="textHolder">
        
         <span class="text_handler">{{ textShowned }}</span>
        <a class="btnReady" @click="proceed">Proceed</a>
    </div>
</template>

<script>
export default {
        name: 'TextHolder',
        data(){
            return {
                textShowned: `"Welcome Trainees": Congratulations! 
Your team has been admitted to the top-secret 
spy training program at the Invite Japan 
agency. Your team has shown remarkable 
skills and talents so far, but there is much more to learn. 
Before you can be accepted as full-fledged spies at our 
agency, you must prove yourself in the field, and 
demonstrate your puzzle-solving and team working skills...`
            }
        },
        methods:{
            proceed(){
                this.$router.push({ name: 'mission.index' })
            }
        }
}
</script>

<style scoped>
    .textHolder{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }

    .text_handler{
        font-size: 3vw;
        padding: 7%;
        color: white;
        font-weight: regular;
        font-family: CA-Geheimagent;
        letter-spacing: 7px;
    }

    .btnReady{
        color:white;
        font-size: 3vw;
        border-style: solid;
        border-radius: 10px;
        padding: 10px;
        cursor: pointer;
        font-weight: regular;
        font-family: CA-Geheimagent;
    }


</style>